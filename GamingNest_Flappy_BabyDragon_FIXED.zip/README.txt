GamingNest — Baby Dragon / Flappy Edition — FIXED

This build fixes the JavaScript initialization error that caused the menu to appear as a static screen.

Upload index.html to the root of your GitHub Pages repository and replace the previous index.html.

The Flappy gameplay, six distinct dragons, eight color palettes, shop, maps, sounds, high score and GamingNest branding are retained.
