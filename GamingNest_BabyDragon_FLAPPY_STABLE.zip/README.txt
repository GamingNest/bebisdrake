GamingNest Baby Dragon — Stable Flappy Edition

This is a clean standalone build. Upload ONLY index.html to the root of your GitHub Pages repository.
It intentionally avoids newer JavaScript syntax that can cause problems on some Safari versions.
