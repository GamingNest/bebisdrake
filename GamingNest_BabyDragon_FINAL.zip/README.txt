GamingNest — Baby Dragon FINAL
================================

This is the finished English web-game build.

Included:
- GamingNest branding
- Baby Dragon home screen
- Play / pause
- High score and coin system
- Dragon unlock shop
- Dragon selection
- 8 color variants
- 4 maps
- Sound toggle
- Haptic feedback where supported
- Local save data
- Mobile/iPhone responsive layout
- App icon and splash assets
- Apple touch icon metadata

GitHub Pages:
Upload index.html and the assets folder together to the repository used by:
https://gamingnest.github.io/bebisdrake/

Important:
Keep the assets folder beside index.html, otherwise the icon/splash files will not be found.
